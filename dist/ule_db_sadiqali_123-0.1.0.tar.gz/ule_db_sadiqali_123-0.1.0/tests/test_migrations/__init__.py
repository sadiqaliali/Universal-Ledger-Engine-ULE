"""Tests for Migrations module."""
